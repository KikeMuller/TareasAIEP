using System;
using System.Configuration;
using System.Data.SqlClient;

namespace LogisticaBLL.Configuracion
{
    /// <summary>
    /// Clase para gestionar la conexión a la base de datos
    /// </summary>
    public static class Conexion
    {
        #region Propiedades

        /// <summary>
        /// Obtiene la cadena de conexión desde el archivo de configuración
        /// </summary>
        private static string CadenaConexion
        {
            get
            {
                // Intenta leer desde App.config
                string cadena = ConfigurationManager.ConnectionStrings["LogisticaDB"]?.ConnectionString;

                // Si no existe en config, usa cadena por defecto
                if (string.IsNullOrEmpty(cadena))
                {
                    cadena = @"Server=localhost;Database=LogisticaDB;Integrated Security=true;TrustServerCertificate=true;";
                }

                return cadena;
            }
        }

        #endregion

        #region Métodos Públicos

        /// <summary>
        /// Obtiene una nueva conexión a la base de datos
        /// </summary>
        /// <returns>Objeto SqlConnection configurado</returns>
        public static SqlConnection ObtenerConexion()
        {
            try
            {
                SqlConnection conexion = new SqlConnection(CadenaConexion);
                return conexion;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al crear la conexión: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Prueba la conexión a la base de datos
        /// </summary>
        /// <returns>True si la conexión es exitosa, False en caso contrario</returns>
        public static bool ProbarConexion()
        {
            try
            {
                using (SqlConnection conexion = ObtenerConexion())
                {
                    conexion.Open();
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Prueba la conexión y obtiene información del servidor
        /// </summary>
        /// <param name="mensajeError">Mensaje de error si falla</param>
        /// <param name="infoServidor">Información del servidor si tiene éxito</param>
        /// <returns>True si la conexión es exitosa</returns>
        public static bool ProbarConexionDetallada(out string mensajeError, out string infoServidor)
        {
            mensajeError = string.Empty;
            infoServidor = string.Empty;

            try
            {
                using (SqlConnection conexion = ObtenerConexion())
                {
                    conexion.Open();
                    
                    // Obtener información del servidor
                    infoServidor = $"Servidor: {conexion.DataSource}\n";
                    infoServidor += $"Base de Datos: {conexion.Database}\n";
                    infoServidor += $"Versión: {conexion.ServerVersion}\n";
                    infoServidor += $"Estado: {conexion.State}";

                    return true;
                }
            }
            catch (SqlException ex)
            {
                mensajeError = ObtenerMensajeErrorSQL(ex);
                return false;
            }
            catch (Exception ex)
            {
                mensajeError = $"Error general: {ex.Message}";
                return false;
            }
        }

        /// <summary>
        /// Obtiene un mensaje de error amigable según el código de error SQL
        /// </summary>
        public static string ObtenerMensajeErrorSQL(SqlException ex)
        {
            switch (ex.Number)
            {
                case 2:
                case 53:
                    return "No se puede conectar al servidor. Verifique que SQL Server esté ejecutándose.";
                
                case 4060:
                    return "La base de datos especificada no existe.";
                
                case 18456:
                    return "Error de autenticación. Verifique usuario y contraseña.";
                
                case 2627:
                case 2601:
                    return "Ya existe un registro con esos datos (violación de clave única).";
                
                case 547:
                    return "Operación violó una restricción de integridad referencial.";
                
                default:
                    return $"Error SQL ({ex.Number}): {ex.Message}";
            }
        }

        #endregion

        #region Métodos de Utilidad

        /// <summary>
        /// Obtiene la cadena de conexión configurada (solo para depuración)
        /// </summary>
        /// <returns>Cadena de conexión</returns>
        public static string ObtenerCadenaConexion()
        {
            return CadenaConexion;
        }

        /// <summary>
        /// Verifica si la base de datos existe
        /// </summary>
        public static bool ExisteBaseDatos()
        {
            try
            {
                using (SqlConnection conexion = ObtenerConexion())
                {
                    conexion.Open();
                    
                    SqlCommand cmd = new SqlCommand(
                        "SELECT COUNT(*) FROM sys.databases WHERE name = 'LogisticaDB'", 
                        conexion
                    );
                    
                    int resultado = (int)cmd.ExecuteScalar();
                    return resultado > 0;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion
    }
}