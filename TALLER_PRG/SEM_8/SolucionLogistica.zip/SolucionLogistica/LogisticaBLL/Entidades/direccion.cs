using System;

namespace LogisticaBLL.Entidades
{
    /// <summary>
    /// Representa una dirección de entrega asociada a un cliente
    /// </summary>
    public class Direccion
    {
        #region Propiedades

        public int DireccionID { get; set; }
        public int ClienteID { get; set; }
        public string Calle { get; set; }
        public string Ciudad { get; set; }
        public string Pais { get; set; }
        public string CodigoPostal { get; set; }
        public bool EsPrincipal { get; set; }

        // Propiedad de navegación (opcional)
        public string NombreCliente { get; set; }

        #endregion

        #region Constructores

        /// <summary>
        /// Constructor vacío
        /// </summary>
        public Direccion()
        {
            EsPrincipal = false;
        }

        /// <summary>
        /// Constructor con parámetros básicos
        /// </summary>
        public Direccion(int clienteID, string calle, string ciudad, string pais)
        {
            ClienteID = clienteID;
            Calle = calle;
            Ciudad = ciudad;
            Pais = pais;
            EsPrincipal = false;
        }

        /// <summary>
        /// Constructor completo
        /// </summary>
        public Direccion(int direccionID, int clienteID, string calle, string ciudad, 
                        string pais, string codigoPostal, bool esPrincipal)
        {
            DireccionID = direccionID;
            ClienteID = clienteID;
            Calle = calle;
            Ciudad = ciudad;
            Pais = pais;
            CodigoPostal = codigoPostal;
            EsPrincipal = esPrincipal;
        }

        #endregion

        #region Métodos de Validación

        /// <summary>
        /// Valida que los datos de la dirección sean correctos
        /// </summary>
        /// <param name="mensajeError">Mensaje de error si la validación falla</param>
        /// <returns>True si es válido, False en caso contrario</returns>
        public bool EsValido(out string mensajeError)
        {
            mensajeError = string.Empty;

            // Validar ClienteID
            if (ClienteID <= 0)
            {
                mensajeError = "Debe seleccionar un cliente válido.";
                return false;
            }

            // Validar Calle
            if (string.IsNullOrWhiteSpace(Calle))
            {
                mensajeError = "La calle es obligatoria.";
                return false;
            }

            if (Calle.Length < 5)
            {
                mensajeError = "La calle debe tener al menos 5 caracteres.";
                return false;
            }

            if (Calle.Length > 200)
            {
                mensajeError = "La calle no puede exceder los 200 caracteres.";
                return false;
            }

            // Validar Ciudad
            if (string.IsNullOrWhiteSpace(Ciudad))
            {
                mensajeError = "La ciudad es obligatoria.";
                return false;
            }

            if (Ciudad.Length < 2)
            {
                mensajeError = "La ciudad debe tener al menos 2 caracteres.";
                return false;
            }

            if (Ciudad.Length > 100)
            {
                mensajeError = "La ciudad no puede exceder los 100 caracteres.";
                return false;
            }

            // Validar País
            if (string.IsNullOrWhiteSpace(Pais))
            {
                mensajeError = "El país es obligatorio.";
                return false;
            }

            if (Pais.Length < 2)
            {
                mensajeError = "El país debe tener al menos 2 caracteres.";
                return false;
            }

            if (Pais.Length > 100)
            {
                mensajeError = "El país no puede exceder los 100 caracteres.";
                return false;
            }

            // Validar Código Postal (opcional)
            if (!string.IsNullOrWhiteSpace(CodigoPostal))
            {
                if (CodigoPostal.Length > 20)
                {
                    mensajeError = "El código postal no puede exceder los 20 caracteres.";
                    return false;
                }
            }

            return true;
        }

        #endregion

        #region Métodos Auxiliares

        /// <summary>
        /// Obtiene la dirección completa formateada
        /// </summary>
        public string ObtenerDireccionCompleta()
        {
            string direccionCompleta = $"{Calle}, {Ciudad}, {Pais}";
            
            if (!string.IsNullOrWhiteSpace(CodigoPostal))
            {
                direccionCompleta += $" ({CodigoPostal})";
            }

            if (EsPrincipal)
            {
                direccionCompleta += " [Principal]";
            }

            return direccionCompleta;
        }

        #endregion

        #region Métodos Override

        /// <summary>
        /// Representación en cadena de la dirección
        /// </summary>
        public override string ToString()
        {
            return ObtenerDireccionCompleta();
        }

        /// <summary>
        /// Compara dos direcciones por su ID
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is Direccion))
                return false;

            Direccion otra = (Direccion)obj;
            return this.DireccionID == otra.DireccionID;
        }

        /// <summary>
        /// Obtiene el código hash de la dirección
        /// </summary>
        public override int GetHashCode()
        {
            return DireccionID.GetHashCode();
        }

        #endregion
    }
}