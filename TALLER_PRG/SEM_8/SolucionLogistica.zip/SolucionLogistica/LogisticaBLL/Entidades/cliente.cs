using System;
using System.Text.RegularExpressions;

namespace LogisticaBLL.Entidades
{
    /// <summary>
    /// Representa un cliente en el sistema de logística
    /// </summary>
    public class Cliente
    {
        #region Propiedades

        public int ClienteID { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public DateTime FechaRegistro { get; set; }

        #endregion

        #region Constructores

        /// <summary>
        /// Constructor vacío
        /// </summary>
        public Cliente()
        {
            FechaRegistro = DateTime.Now;
        }

        /// <summary>
        /// Constructor con parámetros
        /// </summary>
        public Cliente(string nombre, string telefono, string email)
        {
            Nombre = nombre;
            Telefono = telefono;
            Email = email;
            FechaRegistro = DateTime.Now;
        }

        /// <summary>
        /// Constructor completo
        /// </summary>
        public Cliente(int clienteID, string nombre, string telefono, string email, DateTime fechaRegistro)
        {
            ClienteID = clienteID;
            Nombre = nombre;
            Telefono = telefono;
            Email = email;
            FechaRegistro = fechaRegistro;
        }

        #endregion

        #region Métodos de Validación

        /// <summary>
        /// Valida que los datos del cliente sean correctos
        /// </summary>
        /// <param name="mensajeError">Mensaje de error si la validación falla</param>
        /// <returns>True si es válido, False en caso contrario</returns>
        public bool EsValido(out string mensajeError)
        {
            mensajeError = string.Empty;

            // Validar nombre
            if (string.IsNullOrWhiteSpace(Nombre))
            {
                mensajeError = "El nombre del cliente es obligatorio.";
                return false;
            }

            if (Nombre.Length < 3)
            {
                mensajeError = "El nombre debe tener al menos 3 caracteres.";
                return false;
            }

            if (Nombre.Length > 100)
            {
                mensajeError = "El nombre no puede exceder los 100 caracteres.";
                return false;
            }

            // Validar email
            if (string.IsNullOrWhiteSpace(Email))
            {
                mensajeError = "El email es obligatorio.";
                return false;
            }

            if (!EsEmailValido(Email))
            {
                mensajeError = "El formato del email no es válido.";
                return false;
            }

            if (Email.Length > 100)
            {
                mensajeError = "El email no puede exceder los 100 caracteres.";
                return false;
            }

            // Validar teléfono (opcional)
            if (!string.IsNullOrWhiteSpace(Telefono))
            {
                if (Telefono.Length > 20)
                {
                    mensajeError = "El teléfono no puede exceder los 20 caracteres.";
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Valida el formato del email usando expresión regular
        /// </summary>
        private bool EsEmailValido(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                // Patrón de validación de email
                string patron = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
                return Regex.IsMatch(email, patron, RegexOptions.IgnoreCase);
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion

        #region Métodos Override

        /// <summary>
        /// Representación en cadena del cliente
        /// </summary>
        public override string ToString()
        {
            return $"{ClienteID} - {Nombre} ({Email})";
        }

        /// <summary>
        /// Compara dos clientes por su ID
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is Cliente))
                return false;

            Cliente otro = (Cliente)obj;
            return this.ClienteID == otro.ClienteID;
        }

        /// <summary>
        /// Obtiene el código hash del cliente
        /// </summary>
        public override int GetHashCode()
        {
            return ClienteID.GetHashCode();
        }

        #endregion
    }
}