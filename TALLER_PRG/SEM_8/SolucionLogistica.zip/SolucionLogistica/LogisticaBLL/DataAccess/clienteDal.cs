using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using LogisticaBLL.Entidades;
using LogisticaBLL.Configuracion;

namespace LogisticaBLL.DataAccess
{
    /// <summary>
    /// Capa de acceso a datos para la entidad Cliente
    /// </summary>
    public class ClienteDAL
    {
        #region Métodos CREATE

        /// <summary>
        /// Inserta un nuevo cliente en la base de datos
        /// </summary>
        /// <param name="cliente">Cliente a insertar</param>
        /// <returns>ID del cliente insertado</returns>
        public int Insertar(Cliente cliente)
        {
            // Validar datos
            if (!cliente.EsValido(out string mensajeError))
            {
                throw new ArgumentException(mensajeError);
            }

            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"INSERT INTO Clientes (Nombre, Telefono, Email) 
                                   VALUES (@Nombre, @Telefono, @Email);
                                   SELECT CAST(SCOPE_IDENTITY() AS INT);";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                    cmd.Parameters.AddWithValue("@Telefono", cliente.Telefono ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Email", cliente.Email);

                    conexion.Open();
                    int clienteID = (int)cmd.ExecuteScalar();
                    return clienteID;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al insertar cliente: {ex.Message}", ex);
            }
        }

        #endregion

        #region Métodos READ

        /// <summary>
        /// Obtiene todos los clientes
        /// </summary>
        /// <returns>DataTable con todos los clientes</returns>
        public DataTable ObtenerTodos()
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"SELECT ClienteID, Nombre, Telefono, Email, FechaRegistro 
                                   FROM Clientes 
                                   ORDER BY Nombre";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, conexion);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al obtener clientes: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Obtiene un cliente por su ID
        /// </summary>
        /// <param name="clienteID">ID del cliente</param>
        /// <returns>Objeto Cliente o null si no existe</returns>
        public Cliente ObtenerPorID(int clienteID)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"SELECT ClienteID, Nombre, Telefono, Email, FechaRegistro 
                                   FROM Clientes 
                                   WHERE ClienteID = @ClienteID";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@ClienteID", clienteID);

                    conexion.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        return new Cliente
                        {
                            ClienteID = (int)reader["ClienteID"],
                            Nombre = reader["Nombre"].ToString(),
                            Telefono = reader["Telefono"] == DBNull.Value ? null : reader["Telefono"].ToString(),
                            Email = reader["Email"].ToString(),
                            FechaRegistro = (DateTime)reader["FechaRegistro"]
                        };
                    }
                    return null;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al obtener cliente: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Busca clientes por nombre o email
        /// </summary>
        /// <param name="criterio">Criterio de búsqueda</param>
        /// <returns>DataTable con clientes encontrados</returns>
        public DataTable Buscar(string criterio)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"SELECT ClienteID, Nombre, Telefono, Email, FechaRegistro 
                                   FROM Clientes 
                                   WHERE Nombre LIKE @Criterio 
                                   OR Email LIKE @Criterio
                                   ORDER BY Nombre";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@Criterio", "%" + criterio + "%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al buscar clientes: {ex.Message}", ex);
            }
        }

        #endregion

        #region Métodos UPDATE

        /// <summary>
        /// Actualiza un cliente existente
        /// </summary>
        /// <param name="cliente">Cliente con datos actualizados</param>
        /// <returns>True si se actualizó correctamente</returns>
        public bool Actualizar(Cliente cliente)
        {
            // Validar datos
            if (!cliente.EsValido(out string mensajeError))
            {
                throw new ArgumentException(mensajeError);
            }

            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"UPDATE Clientes 
                                   SET Nombre = @Nombre, 
                                       Telefono = @Telefono, 
                                       Email = @Email
                                   WHERE ClienteID = @ClienteID";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@ClienteID", cliente.ClienteID);
                    cmd.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                    cmd.Parameters.AddWithValue("@Telefono", cliente.Telefono ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Email", cliente.Email);

                    conexion.Open();
                    int filasAfectadas = cmd.ExecuteNonQuery();
                    return filasAfectadas > 0;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al actualizar cliente: {ex.Message}", ex);
            }
        }

        #endregion

        #region Métodos DELETE

        /// <summary>
        /// Elimina un cliente por su ID
        /// </summary>
        /// <param name="clienteID">ID del cliente a eliminar</param>
        /// <returns>True si se eliminó correctamente</returns>
        public bool Eliminar(int clienteID)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = "DELETE FROM Clientes WHERE ClienteID = @ClienteID";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@ClienteID", clienteID);

                    conexion.Open();
                    int filasAfectadas = cmd.ExecuteNonQuery();
                    return filasAfectadas > 0;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al eliminar cliente: {ex.Message}", ex);
            }
        }

        #endregion

        #region Métodos Auxiliares

        /// <summary>
        /// Verifica si existe un cliente con el email especificado
        /// </summary>
        /// <param name="email">Email a verificar</param>
        /// <param name="clienteID">ID del cliente a excluir (para actualización)</param>
        /// <returns>True si existe otro cliente con ese email</returns>
        public bool ExisteEmail(string email, int clienteID = 0)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"SELECT COUNT(*) FROM Clientes 
                                   WHERE Email = @Email 
                                   AND ClienteID != @ClienteID";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@ClienteID", clienteID);

                    conexion.Open();
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Obtiene el número total de clientes
        /// </summary>
        public int ObtenerTotalClientes()
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = "SELECT COUNT(*) FROM Clientes";
                    SqlCommand cmd = new SqlCommand(query, conexion);

                    conexion.Open();
                    return (int)cmd.ExecuteScalar();
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        #endregion
    }
}