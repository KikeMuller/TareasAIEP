using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using LogisticaBLL.Entidades;
using LogisticaBLL.Configuracion;

namespace LogisticaBLL.DataAccess
{
    /// <summary>
    /// Capa de acceso a datos para la entidad Direccion
    /// </summary>
    public class DireccionDAL
    {
        #region Métodos CREATE

        /// <summary>
        /// Inserta una nueva dirección en la base de datos
        /// </summary>
        /// <param name="direccion">Dirección a insertar</param>
        /// <returns>ID de la dirección insertada</returns>
        public int Insertar(Direccion direccion)
        {
            // Validar datos
            if (!direccion.EsValido(out string mensajeError))
            {
                throw new ArgumentException(mensajeError);
            }

            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"INSERT INTO Direcciones 
                                   (ClienteID, Calle, Ciudad, Pais, CodigoPostal, EsPrincipal) 
                                   VALUES (@ClienteID, @Calle, @Ciudad, @Pais, @CodigoPostal, @EsPrincipal);
                                   SELECT CAST(SCOPE_IDENTITY() AS INT);";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@ClienteID", direccion.ClienteID);
                    cmd.Parameters.AddWithValue("@Calle", direccion.Calle);
                    cmd.Parameters.AddWithValue("@Ciudad", direccion.Ciudad);
                    cmd.Parameters.AddWithValue("@Pais", direccion.Pais);
                    cmd.Parameters.AddWithValue("@CodigoPostal", direccion.CodigoPostal ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@EsPrincipal", direccion.EsPrincipal);

                    conexion.Open();
                    int direccionID = (int)cmd.ExecuteScalar();
                    return direccionID;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al insertar dirección: {ex.Message}", ex);
            }
        }

        #endregion

        #region Métodos READ

        /// <summary>
        /// Obtiene todas las direcciones
        /// </summary>
        /// <returns>DataTable con todas las direcciones</returns>
        public DataTable ObtenerTodas()
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"SELECT 
                                       d.DireccionID, 
                                       d.ClienteID, 
                                       c.Nombre AS NombreCliente,
                                       d.Calle, 
                                       d.Ciudad, 
                                       d.Pais, 
                                       d.CodigoPostal,
                                       d.EsPrincipal
                                   FROM Direcciones d
                                   INNER JOIN Clientes c ON d.ClienteID = c.ClienteID
                                   ORDER BY c.Nombre, d.EsPrincipal DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, conexion);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al obtener direcciones: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Obtiene todas las direcciones de un cliente específico
        /// </summary>
        /// <param name="clienteID">ID del cliente</param>
        /// <returns>DataTable con las direcciones del cliente</returns>
        public DataTable ObtenerPorCliente(int clienteID)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"SELECT 
                                       d.DireccionID, 
                                       d.ClienteID, 
                                       c.Nombre AS NombreCliente,
                                       d.Calle, 
                                       d.Ciudad, 
                                       d.Pais, 
                                       d.CodigoPostal,
                                       d.EsPrincipal
                                   FROM Direcciones d
                                   INNER JOIN Clientes c ON d.ClienteID = c.ClienteID
                                   WHERE d.ClienteID = @ClienteID
                                   ORDER BY d.EsPrincipal DESC, d.DireccionID";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@ClienteID", clienteID);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al obtener direcciones del cliente: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Obtiene una dirección por su ID
        /// </summary>
        /// <param name="direccionID">ID de la dirección</param>
        /// <returns>Objeto Direccion o null si no existe</returns>
        public Direccion ObtenerPorID(int direccionID)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"SELECT 
                                       d.DireccionID, 
                                       d.ClienteID, 
                                       c.Nombre AS NombreCliente,
                                       d.Calle, 
                                       d.Ciudad, 
                                       d.Pais, 
                                       d.CodigoPostal,
                                       d.EsPrincipal
                                   FROM Direcciones d
                                   INNER JOIN Clientes c ON d.ClienteID = c.ClienteID
                                   WHERE d.DireccionID = @DireccionID";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@DireccionID", direccionID);

                    conexion.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        return new Direccion
                        {
                            DireccionID = (int)reader["DireccionID"],
                            ClienteID = (int)reader["ClienteID"],
                            NombreCliente = reader["NombreCliente"].ToString(),
                            Calle = reader["Calle"].ToString(),
                            Ciudad = reader["Ciudad"].ToString(),
                            Pais = reader["Pais"].ToString(),
                            CodigoPostal = reader["CodigoPostal"] == DBNull.Value ? null : reader["CodigoPostal"].ToString(),
                            EsPrincipal = (bool)reader["EsPrincipal"]
                        };
                    }
                    return null;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al obtener dirección: {ex.Message}", ex);
            }
        }

        #endregion

        #region Métodos UPDATE

        /// <summary>
        /// Actualiza una dirección existente
        /// </summary>
        /// <param name="direccion">Dirección con datos actualizados</param>
        /// <returns>True si se actualizó correctamente</returns>
        public bool Actualizar(Direccion direccion)
        {
            // Validar datos
            if (!direccion.EsValido(out string mensajeError))
            {
                throw new ArgumentException(mensajeError);
            }

            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = @"UPDATE Direcciones 
                                   SET ClienteID = @ClienteID,
                                       Calle = @Calle, 
                                       Ciudad = @Ciudad, 
                                       Pais = @Pais,
                                       CodigoPostal = @CodigoPostal,
                                       EsPrincipal = @EsPrincipal
                                   WHERE DireccionID = @DireccionID";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@DireccionID", direccion.DireccionID);
                    cmd.Parameters.AddWithValue("@ClienteID", direccion.ClienteID);
                    cmd.Parameters.AddWithValue("@Calle", direccion.Calle);
                    cmd.Parameters.AddWithValue("@Ciudad", direccion.Ciudad);
                    cmd.Parameters.AddWithValue("@Pais", direccion.Pais);
                    cmd.Parameters.AddWithValue("@CodigoPostal", direccion.CodigoPostal ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@EsPrincipal", direccion.EsPrincipal);

                    conexion.Open();
                    int filasAfectadas = cmd.ExecuteNonQuery();
                    return filasAfectadas > 0;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al actualizar dirección: {ex.Message}", ex);
            }
        }

        #endregion

        #region Métodos DELETE

        /// <summary>
        /// Elimina una dirección por su ID
        /// </summary>
        /// <param name="direccionID">ID de la dirección a eliminar</param>
        /// <returns>True si se eliminó correctamente</returns>
        public bool Eliminar(int direccionID)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = "DELETE FROM Direcciones WHERE DireccionID = @DireccionID";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@DireccionID", direccionID);

                    conexion.Open();
                    int filasAfectadas = cmd.ExecuteNonQuery();
                    return filasAfectadas > 0;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al eliminar dirección: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Elimina todas las direcciones de un cliente
        /// </summary>
        /// <param name="clienteID">ID del cliente</param>
        /// <returns>Número de direcciones eliminadas</returns>
        public int EliminarPorCliente(int clienteID)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = "DELETE FROM Direcciones WHERE ClienteID = @ClienteID";

                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@ClienteID", clienteID);

                    conexion.Open();
                    return cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al eliminar direcciones: {ex.Message}", ex);
            }
        }

        #endregion

        #region Métodos Auxiliares

        /// <summary>
        /// Obtiene el número de direcciones de un cliente
        /// </summary>
        /// <param name="clienteID">ID del cliente</param>
        /// <returns>Número de direcciones</returns>
        public int ContarDireccionesCliente(int clienteID)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    string query = "SELECT COUNT(*) FROM Direcciones WHERE ClienteID = @ClienteID";
                    SqlCommand cmd = new SqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@ClienteID", clienteID);

                    conexion.Open();
                    return (int)cmd.ExecuteScalar();
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        /// <summary>
        /// Establece una dirección como principal y las demás como secundarias
        /// </summary>
        /// <param name="direccionID">ID de la dirección a establecer como principal</param>
        /// <param name="clienteID">ID del cliente</param>
        /// <returns>True si se actualizó correctamente</returns>
        public bool EstablecerComoPrincipal(int direccionID, int clienteID)
        {
            try
            {
                using (SqlConnection conexion = Conexion.ObtenerConexion())
                {
                    conexion.Open();
                    SqlTransaction transaccion = conexion.BeginTransaction();

                    try
                    {
                        // Desmarcar todas las direcciones del cliente como principales
                        string query1 = "UPDATE Direcciones SET EsPrincipal = 0 WHERE ClienteID = @ClienteID";
                        SqlCommand cmd1 = new SqlCommand(query1, conexion, transaccion);
                        cmd1.Parameters.AddWithValue("@ClienteID", clienteID);
                        cmd1.ExecuteNonQuery();

                        // Marcar la dirección seleccionada como principal
                        string query2 = "UPDATE Direcciones SET EsPrincipal = 1 WHERE DireccionID = @DireccionID";
                        SqlCommand cmd2 = new SqlCommand(query2, conexion, transaccion);
                        cmd2.Parameters.AddWithValue("@DireccionID", direccionID);
                        cmd2.ExecuteNonQuery();

                        transaccion.Commit();
                        return true;
                    }
                    catch (Exception)
                    {
                        transaccion.Rollback();
                        throw;
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(Conexion.ObtenerMensajeErrorSQL(ex), ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al establecer dirección principal: {ex.Message}", ex);
            }
        }

        #endregion
    }
}