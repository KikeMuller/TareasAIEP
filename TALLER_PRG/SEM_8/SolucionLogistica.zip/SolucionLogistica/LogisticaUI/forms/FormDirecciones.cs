using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using LogisticaBLL.Entidades;
using LogisticaBLL.DataAccess;

namespace LogisticaUI
{
    public partial class FormDirecciones : Form
    {
        private DireccionDAL direccionDAL;
        private ClienteDAL clienteDAL;
        private DataGridView dgvDirecciones;
        private ComboBox cboCliente, cboFiltroCliente;
        private TextBox txtCalle, txtCiudad, txtPais, txtCodigoPostal;
        private CheckBox chkEsPrincipal;
        private Button btnNuevo, btnGuardar, btnModificar, btnEliminar, btnCancelar;
        private int direccionIDSeleccionada = 0;
        private bool modoEdicion = false;

        public FormDirecciones()
        {
            InitializeComponent();
            direccionDAL = new DireccionDAL();
            clienteDAL = new ClienteDAL();
            CargarClientes();
            CargarDirecciones();
            EstablecerModoConsulta();
        }

        private void InitializeComponent()
        {
            this.Text = "Gestión de Direcciones";
            this.Size = new Size(1200, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Panel superior - Filtro
            Panel panelFiltro = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.FromArgb(240, 240, 240),
                Padding = new Padding(10)
            };

            Label lblFiltro = new Label
            {
                Text = "Filtrar por Cliente:",
                Location = new Point(10, 20),
                AutoSize = true
            };

            cboFiltroCliente = new ComboBox
            {
                Location = new Point(130, 17),
                Width = 300,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cboFiltroCliente.SelectedIndexChanged += CboFiltroCliente_SelectedIndexChanged;

            Button btnMostrarTodas = new Button
            {
                Text = "Mostrar Todas",
                Location = new Point(440, 15),
                Width = 120,
                Height = 30
            };
            btnMostrarTodas.Click += (s, e) => CargarDirecciones();

            panelFiltro.Controls.AddRange(new Control[] { lblFiltro, cboFiltroCliente, btnMostrarTodas });

            // DataGridView
            dgvDirecciones = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                BackgroundColor = Color.White
            };
            dgvDirecciones.CellClick += DgvDirecciones_CellClick;

            // Panel derecho - Formulario
            Panel panelFormulario = new Panel
            {
                Dock = DockStyle.Right,
                Width = 400,
                BackColor = Color.FromArgb(250, 250, 250),
                Padding = new Padding(20),
                AutoScroll = true
            };

            Label lblTitulo = new Label
            {
                Text = "Datos de la Dirección",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(20, 20),
                AutoSize = true
            };

            // Cliente
            Label lblCliente = new Label { Text = "Cliente:", Location = new Point(20, 70), AutoSize = true };
            cboCliente = new ComboBox
            {
                Location = new Point(20, 95),
                Width = 360,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // Calle
            Label lblCalle = new Label { Text = "Calle:", Location = new Point(20, 130), AutoSize = true };
            txtCalle = new TextBox { Location = new Point(20, 155), Width = 360, MaxLength = 200 };

            // Ciudad
            Label lblCiudad = new Label { Text = "Ciudad:", Location = new Point(20, 190), AutoSize = true };
            txtCiudad = new TextBox { Location = new Point(20, 215), Width = 360, MaxLength = 100 };

            // País
            Label lblPais = new Label { Text = "País:", Location = new Point(20, 250), AutoSize = true };
            txtPais = new TextBox { Location = new Point(20, 275), Width = 360, MaxLength = 100 };

            // Código Postal
            Label lblCodigo = new Label { Text = "Código Postal:", Location = new Point(20, 310), AutoSize = true };
            txtCodigoPostal = new TextBox { Location = new Point(20, 335), Width = 180, MaxLength = 20 };

            // Checkbox Es Principal
            chkEsPrincipal = new CheckBox
            {
                Text = "Dirección Principal",
                Location = new Point(20, 370),
                AutoSize = true,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };

            // Botones de acción
            btnNuevo = new Button
            {
                Text = "➕ Nuevo",
                Location = new Point(20, 410),
                Width = 170,
                Height = 40,
                BackColor = Color.FromArgb(0, 120, 215),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnNuevo.Click += BtnNuevo_Click;

            btnGuardar = new Button
            {
                Text = "💾 Guardar",
                Location = new Point(210, 410),
                Width = 170,
                Height = 40,
                BackColor = Color.FromArgb(16, 124, 16),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btnGuardar.Click += BtnGuardar_Click;

            btnModificar = new Button
            {
                Text = "✏️ Modificar",
                Location = new Point(20, 460),
                Width = 170,
                Height = 40,
                BackColor = Color.FromArgb(255, 140, 0),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btnModificar.Click += BtnModificar_Click;

            btnEliminar = new Button
            {
                Text = "🗑️ Eliminar",
                Location = new Point(210, 460),
                Width = 170,
                Height = 40,
                BackColor = Color.FromArgb(220, 20, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btnEliminar.Click += BtnEliminar_Click;

            btnCancelar = new Button
            {
                Text = "❌ Cancelar",
                Location = new Point(20, 510),
                Width = 360,
                Height = 40,
                Enabled = false
            };
            btnCancelar.Click += BtnCancelar_Click;

            panelFormulario.Controls.AddRange(new Control[] {
                lblTitulo, lblCliente, cboCliente, lblCalle, txtCalle,
                lblCiudad, txtCiudad, lblPais, txtPais, lblCodigo, txtCodigoPostal,
                chkEsPrincipal, btnNuevo, btnGuardar, btnModificar, btnEliminar, btnCancelar
            });

            // Agregar controles al formulario
            this.Controls.Add(dgvDirecciones);
            this.Controls.Add(panelFormulario);
            this.Controls.Add(panelFiltro);
        }

        private void CargarClientes()
        {
            try
            {
                DataTable dtClientes = clienteDAL.ObtenerTodos();

                // Para el ComboBox de filtro
                cboFiltroCliente.Items.Clear();
                cboFiltroCliente.Items.Add("-- Todos los clientes --");
                foreach (DataRow row in dtClientes.Rows)
                {
                    cboFiltroCliente.Items.Add($"{row["ClienteID"]} - {row["Nombre"]}");
                }
                cboFiltroCliente.SelectedIndex = 0;

                // Para el ComboBox del formulario
                cboCliente.Items.Clear();
                foreach (DataRow row in dtClientes.Rows)
                {
                    cboCliente.Items.Add($"{row["ClienteID"]} - {row["Nombre"]}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar clientes:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CargarDirecciones()
        {
            try
            {
                DataTable dt = direccionDAL.ObtenerTodas();
                dgvDirecciones.DataSource = dt;

                if (dgvDirecciones.Columns.Count > 0)
                {
                    dgvDirecciones.Columns["DireccionID"].HeaderText = "ID";
                    dgvDirecciones.Columns["DireccionID"].Width = 50;
                    dgvDirecciones.Columns["ClienteID"].Visible = false;
                    dgvDirecciones.Columns["NombreCliente"].HeaderText = "Cliente";
                    dgvDirecciones.Columns["Calle"].HeaderText = "Calle";
                    dgvDirecciones.Columns["Ciudad"].HeaderText = "Ciudad";
                    dgvDirecciones.Columns["Pais"].HeaderText = "País";
                    dgvDirecciones.Columns["CodigoPostal"].HeaderText = "Código Postal";
                    dgvDirecciones.Columns["EsPrincipal"].HeaderText = "Principal";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar direcciones:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CboFiltroCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cboFiltroCliente.SelectedIndex == 0)
                {
                    CargarDirecciones();
                }
                else
                {
                    string seleccion = cboFiltroCliente.SelectedItem.ToString();
                    int clienteID = int.Parse(seleccion.Split('-')[0].Trim());
                    DataTable dt = direccionDAL.ObtenerPorCliente(clienteID);
                    dgvDirecciones.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al filtrar:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DgvDirecciones_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && !modoEdicion)
            {
                DataGridViewRow fila = dgvDirecciones.Rows[e.RowIndex];
                direccionIDSeleccionada = Convert.ToInt32(fila.Cells["DireccionID"].Value);
                int clienteID = Convert.ToInt32(fila.Cells["ClienteID"].Value);

                // Seleccionar cliente en ComboBox
                for (int i = 0; i < cboCliente.Items.Count; i++)
                {
                    if (cboCliente.Items[i].ToString().StartsWith(clienteID.ToString()))
                    {
                        cboCliente.SelectedIndex = i;
                        break;
                    }
                }

                txtCalle.Text = fila.Cells["Calle"].Value.ToString();
                txtCiudad.Text = fila.Cells["Ciudad"].Value.ToString();
                txtPais.Text = fila.Cells["Pais"].Value.ToString();
                txtCodigoPostal.Text = fila.Cells["CodigoPostal"].Value?.ToString() ?? "";
                chkEsPrincipal.Checked = Convert.ToBoolean(fila.Cells["EsPrincipal"].Value);

                btnModificar.Enabled = true;
                btnEliminar.Enabled = true;
            }
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            EstablecerModoEdicion(false);
            LimpiarCampos();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboCliente.SelectedIndex == -1)
                {
                    MessageBox.Show("Debe seleccionar un cliente", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string seleccionCliente = cboCliente.SelectedItem.ToString();
                int clienteID = int.Parse(seleccionCliente.Split('-')[0].Trim());

                Direccion direccion = new Direccion
                {
                    ClienteID = clienteID,
                    Calle = txtCalle.Text.Trim(),
                    Ciudad = txtCiudad.Text.Trim(),
                    Pais = txtPais.Text.Trim(),
                    CodigoPostal = txtCodigoPostal.Text.Trim(),
                    EsPrincipal = chkEsPrincipal.Checked
                };

                if (!direccion.EsValido(out string mensajeError))
                {
                    MessageBox.Show(mensajeError, "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (modoEdicion)
                {
                    direccion.DireccionID = direccionIDSeleccionada;
                    direccionDAL.Actualizar(direccion);
                    MessageBox.Show("Dirección actualizada exitosamente", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    int nuevoID = direccionDAL.Insertar(direccion);
                    MessageBox.Show($"Dirección creada exitosamente con ID: {nuevoID}", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                CargarDirecciones();
                EstablecerModoConsulta();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar dirección:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {
            EstablecerModoEdicion(true);
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult resultado = MessageBox.Show(
                    "¿Está seguro que desea eliminar esta dirección?",
                    "Confirmar Eliminación",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (resultado == DialogResult.Yes)
                {
                    direccionDAL.Eliminar(direccionIDSeleccionada);
                    MessageBox.Show("Dirección eliminada exitosamente", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarDirecciones();
                    LimpiarCampos();
                    EstablecerModoConsulta();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar dirección:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            EstablecerModoConsulta();
        }

        private void EstablecerModoConsulta()
        {
            modoEdicion = false;
            cboCliente.Enabled = false;
            txtCalle.Enabled = false;
            txtCiudad.Enabled = false;
            txtPais.Enabled = false;
            txtCodigoPostal.Enabled = false;
            chkEsPrincipal.Enabled = false;
            btnNuevo.Enabled = true;
            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void EstablecerModoEdicion(bool esModificacion)
        {
            modoEdicion = esModificacion;
            cboCliente.Enabled = !esModificacion;
            txtCalle.Enabled = true;
            txtCiudad.Enabled = true;
            txtPais.Enabled = true;
            txtCodigoPostal.Enabled = true;
            chkEsPrincipal.Enabled = true;
            btnNuevo.Enabled = false;
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            txtCalle.Focus();
        }

        private void LimpiarCampos()
        {
            direccionIDSeleccionada = 0;
            cboCliente.SelectedIndex = -1;
            txtCalle.Clear();
            txtCiudad.Clear();
            txtPais.Clear();
            txtCodigoPostal.Clear();
            chkEsPrincipal.Checked = false;
        }
    }
}