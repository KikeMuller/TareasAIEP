using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using LogisticaBLL.Entidades;
using LogisticaBLL.DataAccess;

namespace LogisticaUI
{
    public partial class FormClientes : Form
    {
        private ClienteDAL clienteDAL;
        private DataGridView dgvClientes;
        private TextBox txtNombre, txtTelefono, txtEmail, txtBuscar;
        private Button btnNuevo, btnGuardar, btnModificar, btnEliminar, btnCancelar, btnBuscar;
        private int clienteIDSeleccionado = 0;
        private bool modoEdicion = false;

        public FormClientes()
        {
            InitializeComponent();
            clienteDAL = new ClienteDAL();
            CargarClientes();
            EstablecerModoConsulta();
        }

        private void InitializeComponent()
        {
            this.Text = "Gestión de Clientes";
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Panel superior - Búsqueda
            Panel panelBusqueda = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.FromArgb(240, 240, 240),
                Padding = new Padding(10)
            };

            Label lblBuscar = new Label
            {
                Text = "Buscar:",
                Location = new Point(10, 20),
                AutoSize = true
            };

            txtBuscar = new TextBox
            {
                Location = new Point(70, 17),
                Width = 300
            };

            btnBuscar = new Button
            {
                Text = "🔍 Buscar",
                Location = new Point(380, 15),
                Width = 100,
                Height = 30,
                BackColor = Color.FromArgb(0, 120, 215),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnBuscar.Click += BtnBuscar_Click;

            Button btnMostrarTodos = new Button
            {
                Text = "Mostrar Todos",
                Location = new Point(490, 15),
                Width = 120,
                Height = 30
            };
            btnMostrarTodos.Click += (s, e) => CargarClientes();

            panelBusqueda.Controls.AddRange(new Control[] { lblBuscar, txtBuscar, btnBuscar, btnMostrarTodos });

            // DataGridView
            dgvClientes = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                BackgroundColor = Color.White
            };
            dgvClientes.CellClick += DgvClientes_CellClick;

            // Panel derecho - Formulario
            Panel panelFormulario = new Panel
            {
                Dock = DockStyle.Right,
                Width = 350,
                BackColor = Color.FromArgb(250, 250, 250),
                Padding = new Padding(20)
            };

            Label lblTitulo = new Label
            {
                Text = "Datos del Cliente",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(20, 20),
                AutoSize = true
            };

            Label lblNombre = new Label { Text = "Nombre:", Location = new Point(20, 80), AutoSize = true };
            txtNombre = new TextBox { Location = new Point(20, 105), Width = 310, MaxLength = 100 };

            Label lblTelefono = new Label { Text = "Teléfono:", Location = new Point(20, 140), AutoSize = true };
            txtTelefono = new TextBox { Location = new Point(20, 165), Width = 310, MaxLength = 20 };

            Label lblEmail = new Label { Text = "Email:", Location = new Point(20, 200), AutoSize = true };
            txtEmail = new TextBox { Location = new Point(20, 225), Width = 310, MaxLength = 100 };

            // Botones de acción
            btnNuevo = new Button
            {
                Text = "➕ Nuevo",
                Location = new Point(20, 280),
                Width = 150,
                Height = 40,
                BackColor = Color.FromArgb(0, 120, 215),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnNuevo.Click += BtnNuevo_Click;

            btnGuardar = new Button
            {
                Text = "💾 Guardar",
                Location = new Point(180, 280),
                Width = 150,
                Height = 40,
                BackColor = Color.FromArgb(16, 124, 16),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btnGuardar.Click += BtnGuardar_Click;

            btnModificar = new Button
            {
                Text = "✏️ Modificar",
                Location = new Point(20, 330),
                Width = 150,
                Height = 40,
                BackColor = Color.FromArgb(255, 140, 0),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btnModificar.Click += BtnModificar_Click;

            btnEliminar = new Button
            {
                Text = "🗑️ Eliminar",
                Location = new Point(180, 330),
                Width = 150,
                Height = 40,
                BackColor = Color.FromArgb(220, 20, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btnEliminar.Click += BtnEliminar_Click;

            btnCancelar = new Button
            {
                Text = "❌ Cancelar",
                Location = new Point(20, 380),
                Width = 310,
                Height = 40,
                Enabled = false
            };
            btnCancelar.Click += BtnCancelar_Click;

            panelFormulario.Controls.AddRange(new Control[] {
                lblTitulo, lblNombre, txtNombre, lblTelefono, txtTelefono, lblEmail, txtEmail,
                btnNuevo, btnGuardar, btnModificar, btnEliminar, btnCancelar
            });

            // Agregar controles al formulario
            this.Controls.Add(dgvClientes);
            this.Controls.Add(panelFormulario);
            this.Controls.Add(panelBusqueda);
        }

        private void CargarClientes()
        {
            try
            {
                DataTable dt = clienteDAL.ObtenerTodos();
                dgvClientes.DataSource = dt;

                // Configurar columnas
                if (dgvClientes.Columns.Count > 0)
                {
                    dgvClientes.Columns["ClienteID"].HeaderText = "ID";
                    dgvClientes.Columns["ClienteID"].Width = 50;
                    dgvClientes.Columns["Nombre"].HeaderText = "Nombre Completo";
                    dgvClientes.Columns["Telefono"].HeaderText = "Teléfono";
                    dgvClientes.Columns["Email"].HeaderText = "Correo Electrónico";
                    dgvClientes.Columns["FechaRegistro"].HeaderText = "Fecha Registro";
                    dgvClientes.Columns["FechaRegistro"].DefaultCellStyle.Format = "dd/MM/yyyy";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar clientes:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && !modoEdicion)
            {
                DataGridViewRow fila = dgvClientes.Rows[e.RowIndex];
                clienteIDSeleccionado = Convert.ToInt32(fila.Cells["ClienteID"].Value);
                
                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtTelefono.Text = fila.Cells["Telefono"].Value?.ToString() ?? "";
                txtEmail.Text = fila.Cells["Email"].Value.ToString();

                btnModificar.Enabled = true;
                btnEliminar.Enabled = true;
            }
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            EstablecerModoEdicion(false);
            LimpiarCampos();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente cliente = new Cliente
                {
                    Nombre = txtNombre.Text.Trim(),
                    Telefono = txtTelefono.Text.Trim(),
                    Email = txtEmail.Text.Trim()
                };

                if (!cliente.EsValido(out string mensajeError))
                {
                    MessageBox.Show(mensajeError, "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (modoEdicion)
                {
                    cliente.ClienteID = clienteIDSeleccionado;
                    clienteDAL.Actualizar(cliente);
                    MessageBox.Show("Cliente actualizado exitosamente", "Éxito", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    int nuevoID = clienteDAL.Insertar(cliente);
                    MessageBox.Show($"Cliente creado exitosamente con ID: {nuevoID}", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                CargarClientes();
                EstablecerModoConsulta();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar cliente:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {
            EstablecerModoEdicion(true);
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult resultado = MessageBox.Show(
                    "¿Está seguro que desea eliminar este cliente?\nEsta acción también eliminará todas sus direcciones.",
                    "Confirmar Eliminación",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (resultado == DialogResult.Yes)
                {
                    clienteDAL.Eliminar(clienteIDSeleccionado);
                    MessageBox.Show("Cliente eliminado exitosamente", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CargarClientes();
                    LimpiarCampos();
                    EstablecerModoConsulta();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar cliente:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            EstablecerModoConsulta();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                string criterio = txtBuscar.Text.Trim();
                if (string.IsNullOrEmpty(criterio))
                {
                    CargarClientes();
                }
                else
                {
                    DataTable dt = clienteDAL.Buscar(criterio);
                    dgvClientes.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar:\n{ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EstablecerModoConsulta()
        {
            modoEdicion = false;
            txtNombre.Enabled = false;
            txtTelefono.Enabled = false;
            txtEmail.Enabled = false;
            btnNuevo.Enabled = true;
            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void EstablecerModoEdicion(bool esModificacion)
        {
            modoEdicion = esModificacion;
            txtNombre.Enabled = true;
            txtTelefono.Enabled = true;
            txtEmail.Enabled = true;
            btnNuevo.Enabled = false;
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            txtNombre.Focus();
        }

        private void LimpiarCampos()
        {
            clienteIDSeleccionado = 0;
            txtNombre.Clear();
            txtTelefono.Clear();
            txtEmail.Clear();
        }
    }
}