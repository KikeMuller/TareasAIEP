using System;
using System.Windows.Forms;
using LogisticaBLL.Configuracion;

namespace LogisticaUI
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
            this.Text = "Sistema de Gestión de Clientes - Logística Global";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;
            
            // Verificar conexión al cargar
            VerificarConexion();
        }

        private void InitializeComponent()
        {
            // Menú principal
            MenuStrip menuPrincipal = new MenuStrip();
            
            // Menú Clientes
            ToolStripMenuItem menuClientes = new ToolStripMenuItem("&Clientes");
            ToolStripMenuItem itemGestionarClientes = new ToolStripMenuItem("&Gestionar Clientes", null, AbrirGestionClientes);
            itemGestionarClientes.ShortcutKeys = Keys.Control | Keys.C;
            menuClientes.DropDownItems.Add(itemGestionarClientes);
            
            // Menú Direcciones
            ToolStripMenuItem menuDirecciones = new ToolStripMenuItem("&Direcciones");
            ToolStripMenuItem itemGestionarDirecciones = new ToolStripMenuItem("&Gestionar Direcciones", null, AbrirGestionDirecciones);
            itemGestionarDirecciones.ShortcutKeys = Keys.Control | Keys.D;
            menuDirecciones.DropDownItems.Add(itemGestionarDirecciones);
            
            // Menú Herramientas
            ToolStripMenuItem menuHerramientas = new ToolStripMenuItem("&Herramientas");
            ToolStripMenuItem itemProbarConexion = new ToolStripMenuItem("&Probar Conexión", null, ProbarConexion);
            ToolStripMenuItem itemAcercaDe = new ToolStripMenuItem("&Acerca de...", null, MostrarAcercaDe);
            menuHerramientas.DropDownItems.Add(itemProbarConexion);
            menuHerramientas.DropDownItems.Add(new ToolStripSeparator());
            menuHerramientas.DropDownItems.Add(itemAcercaDe);
            
            // Menú Salir
            ToolStripMenuItem menuSalir = new ToolStripMenuItem("&Salir");
            ToolStripMenuItem itemSalir = new ToolStripMenuItem("&Salir", null, Salir);
            itemSalir.ShortcutKeys = Keys.Alt | Keys.F4;
            menuSalir.DropDownItems.Add(itemSalir);
            
            menuPrincipal.Items.AddRange(new ToolStripItem[] {
                menuClientes,
                menuDirecciones,
                menuHerramientas,
                menuSalir
            });
            
            // Panel principal con botones grandes
            Panel panelCentral = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(50)
            };
            
            // Botón Gestionar Clientes
            Button btnClientes = new Button
            {
                Text = "Gestionar\nClientes",
                Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold),
                Size = new System.Drawing.Size(250, 150),
                Location = new System.Drawing.Point(100, 100),
                BackColor = System.Drawing.Color.FromArgb(0, 120, 215),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnClientes.Click += AbrirGestionClientes;
            
            // Botón Gestionar Direcciones
            Button btnDirecciones = new Button
            {
                Text = "Gestionar\nDirecciones",
                Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold),
                Size = new System.Drawing.Size(250, 150),
                Location = new System.Drawing.Point(400, 100),
                BackColor = System.Drawing.Color.FromArgb(16, 124, 16),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnDirecciones.Click += AbrirGestionDirecciones;
            
            // Label de bienvenida
            Label lblBienvenida = new Label
            {
                Text = "Sistema de Gestión de Clientes\nEmpresa de Logística Global",
                Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold),
                AutoSize = false,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Size = new System.Drawing.Size(600, 80),
                Location = new System.Drawing.Point(50, 20),
                ForeColor = System.Drawing.Color.FromArgb(0, 120, 215)
            };
            
            // StatusStrip
            StatusStrip statusStrip = new StatusStrip();
            ToolStripStatusLabel lblStatus = new ToolStripStatusLabel("Listo");
            ToolStripStatusLabel lblFecha = new ToolStripStatusLabel(DateTime.Now.ToString("dd/MM/yyyy HH:mm"));
            statusStrip.Items.AddRange(new ToolStripItem[] { lblStatus, lblFecha });
            
            panelCentral.Controls.AddRange(new Control[] {
                lblBienvenida,
                btnClientes,
                btnDirecciones
            });
            
            // Agregar controles al formulario
            this.MainMenuStrip = menuPrincipal;
            this.Controls.Add(panelCentral);
            this.Controls.Add(menuPrincipal);
            this.Controls.Add(statusStrip);
            
            // Propiedades del formulario
            this.Size = new System.Drawing.Size(1000, 600);
            this.MinimumSize = new System.Drawing.Size(800, 500);
            this.IsMdiContainer = true;
        }

        private void VerificarConexion()
        {
            try
            {
                if (!Conexion.ProbarConexion())
                {
                    MessageBox.Show(
                        "No se pudo conectar a la base de datos.\n\n" +
                        "Por favor, verifique:\n" +
                        "1. SQL Server está ejecutándose\n" +
                        "2. La base de datos 'LogisticaDB' existe\n" +
                        "3. La cadena de conexión en App.config es correcta",
                        "Advertencia de Conexión",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Error al verificar conexión:\n{ex.Message}",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void AbrirGestionClientes(object sender, EventArgs e)
        {
            try
            {
                FormClientes formClientes = new FormClientes();
                formClientes.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Error al abrir gestión de clientes:\n{ex.Message}",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void AbrirGestionDirecciones(object sender, EventArgs e)
        {
            try
            {
                FormDirecciones formDirecciones = new FormDirecciones();
                formDirecciones.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Error al abrir gestión de direcciones:\n{ex.Message}",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void ProbarConexion(object sender, EventArgs e)
        {
            try
            {
                if (Conexion.ProbarConexionDetallada(out string mensajeError, out string infoServidor))
                {
                    MessageBox.Show(
                        "Conexión exitosa!\n\n" + infoServidor,
                        "Prueba de Conexión",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                else
                {
                    MessageBox.Show(
                        "No se pudo conectar a la base de datos.\n\n" + mensajeError,
                        "Error de Conexión",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Error al probar conexión:\n{ex.Message}",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void MostrarAcercaDe(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Sistema de Gestión de Clientes\n" +
                "Versión 1.0.0\n\n" +
                "Desarrollado con:\n" +
                "- C# / .NET Framework 4.7.2\n" +
                "- Windows Forms\n" +
                "- SQL Server\n" +
                "- ADO.NET\n\n" +
                "© 2025 Logística Global S.A.",
                "Acerca de",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void Salir(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show(
                "¿Está seguro que desea salir de la aplicación?",
                "Confirmar Salida",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resultado == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}