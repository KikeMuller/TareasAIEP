using System;
using System.Windows.Forms;

namespace LogisticaUI
{
    /// <summary>
    /// Clase principal de la aplicación
    /// </summary>
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                // Configuración de la aplicación
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                // Configurar manejador global de excepciones
                Application.ThreadException += Application_ThreadException;
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

                // Ejecutar aplicación
                Application.Run(new FormPrincipal());
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Error crítico al iniciar la aplicación:\n\n{ex.Message}\n\n{ex.StackTrace}",
                    "Error Fatal",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        /// <summary>
        /// Manejador de excepciones no controladas en el thread de la interfaz
        /// </summary>
        private static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            try
            {
                MessageBox.Show(
                    $"Se produjo un error inesperado:\n\n{e.Exception.Message}\n\nLa aplicación intentará continuar.",
                    "Error de Aplicación",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );

                // Opcional: Registrar el error en un archivo de log
                RegistrarError(e.Exception);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Error fatal al manejar una excepción:\n{ex.Message}",
                    "Error Crítico",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Stop
                );
            }
        }

        /// <summary>
        /// Manejador de excepciones no controladas en otros threads
        /// </summary>
        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            try
            {
                Exception ex = e.ExceptionObject as Exception;
                string mensaje = ex != null ? ex.Message : "Error desconocido";
                
                MessageBox.Show(
                    $"Error crítico no controlado:\n\n{mensaje}\n\nLa aplicación debe cerrarse.",
                    "Error Fatal",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Stop
                );

                // Registrar el error
                if (ex != null)
                {
                    RegistrarError(ex);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Error al procesar excepción fatal:\n{ex.Message}",
                    "Error Crítico",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Stop
                );
            }
            finally
            {
                Application.Exit();
            }
        }

        /// <summary>
        /// Registra errores en un archivo de log
        /// </summary>
        /// <param name="ex">Excepción a registrar</param>
        private static void RegistrarError(Exception ex)
        {
            try
            {
                string rutaLog = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "error_log.txt"
                );

                string mensajeLog = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex.GetType().Name}: {ex.Message}\n";
                mensajeLog += $"StackTrace: {ex.StackTrace}\n";
                mensajeLog += new string('-', 80) + "\n\n";

                System.IO.File.AppendAllText(rutaLog, mensajeLog);
            }
            catch
            {
                // Si falla el registro de errores, no hacemos nada para evitar un loop infinito
            }
        }
    }
}